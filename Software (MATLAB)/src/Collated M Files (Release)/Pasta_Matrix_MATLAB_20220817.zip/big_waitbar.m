%function waitbar = big_waitbar(varargin)

%figsize = [2,16];                                                           %Set the default figure size, in centimeters.
%barcolor = 'b';                                                             %Set the default waitbar color.
%titlestr = 'Waiting...';                                                    %Set the default waitbar title.
%txtstr = 'Waiting...';                                                      %Set the default waitbar string.
%val = 0;                                                                    %Set the default value of the waitbar to zero.

%str = {'FigureSize','Color','Title','String','Value'};                      %List the allowable parameter names.
%for i = 1:2:length(varargin)                                                %Step through any optional input arguments.
%    if ~ischar(varargin{i}) || ~any(strcmpi(varargin{i},str))               %If the first optional input argument isn't one of the expected property names...
%        beep;                                                               %Play the Matlab warning noise.
%        cprintf('red','%s\n',['ERROR IN BIG_WAITBAR: Property '...
%            'name not recognized! Optional input properties are:']);        %Show an error.
%        for j = 1:length(str)                                               %Step through each allowable parameter name.
%            cprintf('red','\t%s\n',str{j});                                 %List each parameter name in the command window, in red.
%        end
%        return                                                              %Skip execution of the rest of the function.
%    else                                                                    %Otherwise...
%        if strcmpi(varargin{i},'FigureSize')                                %If the optional input property is "FigureSize"...
%            figsize = varargin{i+1};                                        %Set the figure size to that specified, in centimeters.            
%        elseif strcmpi(varargin{i},'Color')                                 %If the optional input property is "Color"...
%            barcolor = varargin{i+1};                                       %Set the waitbar color the specified color.
%        elseif strcmpi(varargin{i},'Title')                                 %If the optional input property is "Title"...
%            titlestr = varargin{i+1};                                       %Set the waitbar figure title to the specified string.
%        elseif strcmpi(varargin{i},'String')                                %If the optional input property is "String"...
%            txtstr = varargin{i+1};                                         %Set the waitbar text to the specified string.
%        elseif strcmpi(varargin{i},'Value')                                 %If the optional input property is "Value"...
%            val = varargin{i+1};                                            %Set the waitbar value to the specified value.
%        end
%    end    
%end

%orig_units = get(0,'units');                                                %Grab the current system units.
%set(0,'units','centimeters');                                               %Set the system units to centimeters.
%pos = get(0,'Screensize');                                                  %Grab the screensize.
%h = figsize(1);                                                             %Set the height of the figure.
%w = figsize(2);                                                             %Set the width of the figure.
%fig = figure('numbertitle','off',...
%    'name',titlestr,...
%    'units','centimeters',...
%    'Position',[pos(3)/2-w/2, pos(4)/2-h/2, w, h],...
%    'menubar','none',...
%    'resize','off');                                                        %Create a figure centered in the screen.
%ax = axes('units','centimeters',...
%    'position',[0.25,0.25,w-0.5,h/2-0.3],...
%    'parent',fig);                                                          %Create axes for showing loading progress.
%if val > 1                                                                  %If the specified value is greater than 1...
%    val = 1;                                                                %Set the value to 1.
%elseif val < 0                                                              %If the specified value is less than 0...
%    val = 0;                                                                %Set the value to 0.
%end    
%obj = fill(val*[0 1 1 0 0],[0 0 1 1 0],barcolor,'edgecolor','k');           %Create a fill object to show loading progress.
%set(ax,'xtick',[],'ytick',[],'box','on','xlim',[0,1],'ylim',[0,1]);         %Set the axis limits and ticks.
%txt = uicontrol(fig,'style','text','units','centimeters',...
%    'position',[0.25,h/2+0.05,w-0.5,h/2-0.3],'fontsize',10,...
%    'horizontalalignment','left','backgroundcolor',get(fig,'color'),...
%    'string',txtstr);                                                       %Create a text object to show the current point in the wait process.  
%set(0,'units',orig_units);                                                  %Set the system units back to the original units.

%waitbar.title = @(str)SetTitle(fig,str);                                    %Set the function for changing the waitbar title.
%waitbar.string = @(str)SetString(fig,txt,str);                              %Set the function for changing the waitbar string.
%waitbar.value = @(val)SetVal(fig,obj,val);                                  %Set the function for changing waitbar value.
%waitbar.color = @(val)SetColor(fig,obj,val);                                %Set the function for changing waitbar color.
%waitbar.close = @()CloseWaitbar(fig);                                       %Set the function for closing the waitbar.
%waitbar.isclosed = @()WaitbarIsClosed(fig);                                 %Set the function for checking whether the waitbar figure is closed.

%drawnow;                                                                    %Immediately show the waitbar.


%%% This function sets the name/title of the waitbar figure.
%function SetTitle(fig,str)
%if ishandle(fig)                                                            %If the waitbar figure is still open...
%    set(fig,'name',str);                                                    %Set the figure name to the specified string.
%    drawnow;                                                                %Immediately update the figure.
%else                                                                        %Otherwise...
%    warning('Cannot update the waitbar figure. It has been closed.');       %Show a warning.
%end


%%% This function sets the string on the waitbar figure.
%function SetString(fig,txt,str)
%if ishandle(fig)                                                            %If the waitbar figure is still open...
%    set(txt,'string',str);                                                  %Set the string in the text object to the specified string.
%    drawnow;                                                                %Immediately update the figure.
%else                                                                        %Otherwise...
%    warning('Cannot update the waitbar figure. It has been closed.');       %Show a warning.
%end


%%% This function sets the current value of the waitbar.
%function SetVal(fig,obj,val)
%if ishandle(fig)                                                            %If the waitbar figure is still open...
%    if val > 1                                                              %If the specified value is greater than 1...
%        val = 1;                                                            %Set the value to 1.
%    elseif val < 0                                                          %If the specified value is less than 0...
%        val = 0;                                                            %Set the value to 0.
%    end
%    set(obj,'xdata',val*[0 1 1 0 0]);                                       %Set the patch object to extend to the specified value.
%    drawnow;                                                                %Immediately update the figure.
%else                                                                        %Otherwise...
%    warning('Cannot update the waitbar figure. It has been closed.');       %Show a warning.
%end


%%% This function sets the color of the waitbar.
%function SetColor(fig,obj,val)
%if ishandle(fig)                                                            %If the waitbar figure is still open...
%    set(obj,'facecolor',val);                                               %Set the patch object to have the specified facecolor.
%    drawnow;                                                                %Immediately update the figure.
%else                                                                        %Otherwise...
%    warning('Cannot update the waitbar figure. It has been closed.');       %Show a warning.
%end


%%% This function closes the waitbar figure.
%function CloseWaitbar(fig)
%if ishandle(fig)                                                            %If the waitbar figure is still open...
%    close(fig);                                                             %Close the waitbar figure.
%    drawnow;                                                                %Immediately update the figure to allow it to close.
%end


%%% This function returns a logical value indicate whether the waitbar figure has been closed.
%function isclosed = WaitbarIsClosed(fig)
%isclosed = ~ishandle(fig);                                                  %Check to see if the figure handle is still a valid handle.